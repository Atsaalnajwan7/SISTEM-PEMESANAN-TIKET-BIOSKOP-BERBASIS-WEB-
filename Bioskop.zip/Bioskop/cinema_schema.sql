-- Buat tabel categories
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
);

-- Buat tabel items
CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    categoryName VARCHAR(100),
    FOREIGN KEY (categoryName) REFERENCES categories(name)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Buat index pada nama kategori
ALTER TABLE categories
ADD INDEX idx_name (name);

-- Buat tabel rooms
CREATE TABLE IF NOT EXISTS rooms (
    roomId INT PRIMARY KEY,
    NbSeats INT NOT NULL,
    available BOOLEAN DEFAULT 1
);

-- Buat tabel seats
CREATE TABLE IF NOT EXISTS seats (
    room_id INT,
    seatId INT,
    available BOOLEAN DEFAULT 1,
    reservedBy VARCHAR(100),
    htmlClass VARCHAR(50),
    PRIMARY KEY (room_id, seatId),
    FOREIGN KEY (room_id) REFERENCES rooms(roomId)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Masukkan data untuk tabel rooms
INSERT INTO rooms (roomId, NbSeats, available) VALUES
(1, 42, 1),
(2, 42, 1),
(3, 42, 1),
(4, 42, 1),
(5, 42, 1),
(6, 42, 1),
(7, 42, 1),
(8, 42, 1),
(9, 42, 1),
(10, 42, 1);

-- Masukkan data ke tabel seats (potongan awal sebagai contoh)
INSERT INTO seats (room_id, seatId, available, reservedBy, htmlClass) VALUES
(1, 1, 1, NULL, 'seat'),
(1, 2, 1, NULL, 'seat'),
(1, 3, 1, NULL, 'seat'),
(1, 4, 1, NULL, 'seat'),
(1, 5, 1, NULL, 'seat'),
(1, 6, 1, NULL, 'seat'),
(1, 7, 1, NULL, 'seat'),
(1, 8, 1, NULL, 'seat'),
(1, 9, 1, NULL, 'seat'),
(1, 10, 1, NULL, 'seat');
-- Tambahkan sisa baris kursi jika diperlukan
