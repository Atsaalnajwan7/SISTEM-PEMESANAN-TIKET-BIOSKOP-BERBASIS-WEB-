from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, g, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date, timedelta
import os
from werkzeug.utils import secure_filename
import uuid # <-- TAMBAHKAN INI UNTUK NAMA FILE UNIK

# Inisialisasi Aplikasi Flask
app = Flask(__name__)

# Konfigurasi Database (SQLite)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'instance', 'cinema.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_strong_secret_key_here_ganti_ini_dengan_kunci_unik' # GANTI INI DENGAN KUNCI YANG KUAT!

# --- BARU: Batas Ukuran File Upload (Opsional, tapi direkomendasikan) ---
# Maksimum 16 Megabyte. Sesuaikan sesuai kebutuhan.
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024


# Inisialisasi SQLAlchemy
db = SQLAlchemy(app)

# --- Konfigurasi Flask-Login ---
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login' # Nama fungsi view untuk halaman login

# Kelas Model Pengguna (User)
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    Uname = db.Column(db.String(100), nullable=False) # Nama Lengkap
    email = db.Column(db.String(120), unique=True, nullable=True)
    dob = db.Column(db.Date, nullable=True) # Date of Birth
    # Perbarui default value, pastikan 'default.jpg' ada di UPLOAD_FOLDER_PROFILE_PICTURES
    profile_picture = db.Column(db.String(255), nullable=True, default='default.jpg')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.username}>'

# Kelas Model Film (Movie)
class Movie(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=True)
    release_date = db.Column(db.Date, nullable=True)
    director = db.Column(db.String(100), nullable=True)
    image_filename = db.Column(db.String(255), nullable=True, default='default_movie.jpg') # Nama file poster film, tambahkan default
    category = db.Column(db.String(50), nullable=True)
    duration = db.Column(db.Integer, nullable=True) # <-- BARU: Kolom durasi film dalam menit

    def __repr__(self):
        return f'<Movie {self.title}>'

# --- Konfigurasi Folder Upload ---
# BASEDIR sudah didefinisikan di atas
UPLOAD_FOLDER_MOVIE_POSTERS = os.path.join(basedir, 'static', 'uploads', 'movie_posters')
if not os.path.exists(UPLOAD_FOLDER_MOVIE_POSTERS):
    os.makedirs(UPLOAD_FOLDER_MOVIE_POSTERS)
app.config['UPLOAD_FOLDER_MOVIE_POSTERS'] = UPLOAD_FOLDER_MOVIE_POSTERS

UPLOAD_FOLDER_PROFILE_PICTURES = os.path.join(basedir, 'static', 'uploads', 'profile_pictures')
if not os.path.exists(UPLOAD_FOLDER_PROFILE_PICTURES):
    os.makedirs(UPLOAD_FOLDER_PROFILE_PICTURES)
app.config['UPLOAD_FOLDER_PROFILE_PICTURES'] = UPLOAD_FOLDER_PROFILE_PICTURES

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# --- Flask-Login User Loader ---
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- Global Context Processor (untuk 'g.user' dan 'current_year' di semua template) ---
@app.before_request
def before_request():
    # Menetapkan current_user ke g.user agar mudah diakses di template
    g.user = current_user

@app.context_processor
def inject_current_year():
    # Menambahkan current_year ke semua konteks template
    return {'current_year': datetime.now().year}


# --- ROUTE UTAMA YANG SUDAH DIREVISI ---
@app.route('/')
def root_redirect():
    if not current_user.is_authenticated:
        # Jika belum login, redirect ke halaman login
        return redirect(url_for('login'))
    else:
        # Jika sudah login, redirect ke halaman utama (movies)
        return redirect(url_for('movies'))

# ----- ROUTE Halaman Login ('/login') -----
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        # Jika sudah login, jangan tampilkan login lagi, langsung ke movies
        return redirect(url_for('movies'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user)
            flash('Login berhasil!', 'success')
            next_page = request.args.get('next')
            # Setelah login berhasil, arahkan ke halaman 'movies' atau 'index' jika 'next' tidak ada
            return redirect(next_page or url_for('movies'))
        else:
            flash('Username atau Password salah.', 'error')
    return render_template('login.html') # Mengasumsikan nama file adalah login.html

# ----- ROUTE Halaman Pendaftaran ('/signup') -----
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('movies'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        Uname = request.form.get('Uname')
        email = request.form.get('email')
        dob_str = request.form.get('dob')

        if not username or not password or not Uname:
            flash("Username, Nama Lengkap, dan Password tidak boleh kosong.", "error")
            return redirect(url_for('signup'))

        dob = None
        if dob_str:
            try:
                dob = datetime.strptime(dob_str, '%Y-%m-%d').date()
            except ValueError:
                flash("Format tanggal lahir tidak valid. Gunakan YYYY-MM-DD.", "error")
                return redirect(url_for('signup'))

        if User.query.filter_by(username=username).first():
            flash("Username sudah digunakan. Silakan pilih yang lain.", "error")
            return redirect(url_for('signup'))

        if email and User.query.filter_by(email=email).first():
            flash("Email sudah terdaftar. Silakan gunakan email lain atau login.", "error")
            return redirect(url_for('signup'))

        # Saat pendaftaran, default profile_picture akan diset oleh model User (default='default.jpg')
        new_user = User(username=username, Uname=Uname, email=email, dob=dob)
        new_user.set_password(password)

        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Akun berhasil dibuat! Silakan login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Terjadi kesalahan saat pendaftaran: {str(e)}', 'error')
            return redirect(url_for('signup'))

    return render_template('signup.html') # Mengasumsikan nama file adalah signup.html

# ----- ROUTE Halaman Lupa Password ('/forgot_password') -----
@app.route('/forgot_password')
def forgot_password():
    return render_template('forgot_password.html') # Mengasumsikan nama file adalah forgot_password.html

# ----- ROUTE Halaman Logout ('/logout') -----
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Anda telah berhasil logout.', 'info')
    return redirect(url_for('login'))


# ----- ROUTE Halaman Film ('/movies') -----
# Inilah halaman "utama" setelah login, yang menampilkan daftar film
@app.route('/movies')
@login_required # Hanya bisa diakses jika sudah login
def movies():
    current_date = date.today()
    # Filter film yang sudah rilis
    released_movies = Movie.query.filter(Movie.release_date <= current_date).order_by(Movie.release_date.desc()).all()

    # Filter "rilis baru" (misalnya, dalam 60 hari terakhir)
    sixty_days_ago = current_date - timedelta(days=60)
    new_releases = Movie.query.filter(
        Movie.release_date.between(sixty_days_ago, current_date)
    ).order_by(Movie.release_date.desc()).all()

    # Film unggulan (misalnya, 5 film terbaru yang sudah rilis)
    featured_movies = released_movies[:5]

    # Film yang akan datang
    coming_soon_movies = Movie.query.filter(Movie.release_date > current_date).order_by(Movie.release_date.asc()).all()

    # Logika filter berdasarkan kategori
    category = request.args.get('category')
    if category and category != 'all':
        all_movies = Movie.query.filter_by(category=category).all()
    else:
        all_movies = Movie.query.all() # Semua film jika tidak ada filter kategori

    return render_template(
        'movies.html',
        user=g.user, # g.user otomatis tersedia karena @app.before_request
        new_releases=new_releases,
        featured_movies=featured_movies,
        coming_soon=coming_soon_movies,
        movies=all_movies # Melewatkan semua film (atau yang difilter) untuk bagian "All Movies" atau filter
    )


# ----- ROUTE Halaman Tambah Film ('/add_movie') -----
@app.route('/add_movie', methods=['GET', 'POST'])
@login_required
def add_movie():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        release_date_str = request.form.get('release_date')
        director = request.form.get('director')
        category = request.form.get('category')
        duration = request.form.get('duration', type=int) # BARU: Ambil durasi

        if not title:
            flash("Judul film tidak boleh kosong.", "error")
            return redirect(url_for('add_movie'))

        release_date = None
        if release_date_str:
            try:
                release_date = datetime.strptime(release_date_str, '%Y-%m-%d').date()
            except ValueError:
                flash("Format tanggal rilis tidak valid. Gunakan YYYY-MM-DD.", "error")
                return redirect(url_for('add_movie'))

        image_filename = 'default_movie.jpg' # Default jika tidak ada gambar diunggah
        if 'image' in request.files:
            file = request.files['image']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                image_filename = f"{timestamp}_{filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER_MOVIE_POSTERS'], image_filename))
            elif file.filename != '': # Ada file tapi tidak diizinkan
                flash("Tipe file gambar tidak diizinkan. Hanya PNG, JPG, JPEG, GIF.", "warning")
            # Jika file.filename == '' (input file kosong), tetap gunakan default.jpg

        new_movie = Movie(
            title=title,
            description=description,
            release_date=release_date,
            director=director,
            image_filename=image_filename,
            category=category,
            duration=duration # BARU: Simpan durasi
        )

        try:
            db.session.add(new_movie)
            db.session.commit()
            flash('Film berhasil ditambahkan!', 'success')
            return redirect(url_for('movies'))
        except Exception as e:
            db.session.rollback()
            flash(f'Terjadi kesalahan saat menambahkan film: {str(e)}', 'error')

    return render_template('add_movie.html', user=g.user)

# ROUTE untuk menyajikan gambar movie poster
@app.route('/movie_images/<filename>')
def serve_movie_image(filename):
    # Pastikan filename aman dari traversal direktori
    return send_from_directory(app.config['UPLOAD_FOLDER_MOVIE_POSTERS'], filename)

# ROUTE untuk menyajikan gambar profil
@app.route('/profile_pictures/<filename>')
def serve_profile_picture(filename):
    # Logika untuk gambar default
    if not filename or filename == 'default.jpg': # Sesuaikan dengan nama file default Anda
        # Mengasumsikan default.jpg ada di dalam UPLOAD_FOLDER_PROFILE_PICTURES
        default_path = os.path.join(app.config['UPLOAD_FOLDER_PROFILE_PICTURES'], 'default.jpg')
        if os.path.exists(default_path):
            return send_from_directory(app.config['UPLOAD_FOLDER_PROFILE_PICTURES'], 'default.jpg')
        # Fallback jika default.jpg tidak ada di UPLOAD_FOLDER_PROFILE_PICTURES
        return send_from_directory(os.path.join(basedir, 'static', 'images'), 'default_profile.png') # Contoh fallback

    return send_from_directory(app.config['UPLOAD_FOLDER_PROFILE_PICTURES'], filename)


# ----- ROUTE Halaman Detail Film ('/movie/<int:movie_id>') -----
@app.route('/movie/<int:movie_id>')
@login_required
def movie_detail(movie_id):
    movie = Movie.query.get_or_404(movie_id)
    return render_template('movie_detail.html', movie=movie, user=g.user)

# ----- ROUTE Halaman Edit Film ('/edit_movie/<int:movie_id>') -----
@app.route('/edit_movie/<int:movie_id>', methods=['GET', 'POST'])
@login_required
def edit_movie(movie_id):
    movie = Movie.query.get_or_404(movie_id)

    if request.method == 'POST':
        movie.title = request.form.get('title')
        movie.description = request.form.get('description')
        director = request.form.get('director')
        release_date_str = request.form.get('release_date')
        movie.category = request.form.get('category')
        movie.duration = request.form.get('duration', type=int) # BARU: Update durasi

        if not movie.title:
            flash("Judul film tidak boleh kosong.", "error")
            return redirect(url_for('edit_movie', movie_id=movie.id))

        movie.director = director

        if release_date_str:
            try:
                movie.release_date = datetime.strptime(release_date_str, '%Y-%m-%d').date()
            except ValueError:
                flash("Format tanggal rilis tidak valid. Gunakan YYYY-MM-DD.", "error")
                return redirect(url_for('edit_movie', movie_id=movie.id))
        else:
            movie.release_date = None # Set ke None jika tidak ada tanggal yang dimasukkan

        if 'image' in request.files:
            file = request.files['image']
            if file and allowed_file(file.filename):
                # Hapus gambar lama jika ada dan bukan default.jpg
                if movie.image_filename and movie.image_filename != 'default_movie.jpg': # Sesuaikan nama default film
                    old_path = os.path.join(app.config['UPLOAD_FOLDER_MOVIE_POSTERS'], movie.image_filename)
                    if os.path.exists(old_path):
                        try:
                            os.remove(old_path)
                        except Exception as e:
                            print(f"WARNING: Gagal menghapus gambar lama: {e}")
                filename = secure_filename(file.filename)
                timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                movie.image_filename = f"{timestamp}_{filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER_MOVIE_POSTERS'], movie.image_filename))
            elif file.filename == '':
                pass # Biarkan movie.image_filename tetap seperti semula
            else:
                flash("Tipe file gambar tidak diizinkan. Hanya PNG, JPG, JPEG, GIF.", "warning")
        else:
            pass # Jika tidak ada input file 'image' di form sama sekali

        try:
            db.session.commit()
            flash('Film berhasil diperbarui!', 'success')
            return redirect(url_for('movie_detail', movie_id=movie.id))
        except Exception as e:
            db.session.rollback()
            flash(f'Terjadi kesalahan saat memperbarui film: {str(e)}', 'error')

    return render_template('edit_movie.html', movie=movie, user=g.user)

# ----- ROUTE Halaman Hapus Film ('/delete_movie/<int:movie_id>') -----
@app.route('/delete_movie/<int:movie_id>', methods=['POST'])
@login_required
def delete_movie(movie_id):
    movie = Movie.query.get_or_404(movie_id)

    try:
        # Hapus file poster jika ada dan bukan default_movie.jpg
        if movie.image_filename and movie.image_filename != 'default_movie.jpg': # Sesuaikan nama default film
            file_path = os.path.join(app.config['UPLOAD_FOLDER_MOVIE_POSTERS'], movie.image_filename)
            if os.path.exists(file_path):
                os.remove(file_path)

        db.session.delete(movie)
        db.session.commit()
        flash('Film berhasil dihapus.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Terjadi kesalahan saat menghapus film: {str(e)}', 'error')

    return redirect(url_for('movies'))

# ----- ROUTE Halaman Kelola Film ('/manage_movies') -----
@app.route('/manage_movies')
@login_required
def manage_movies():
    all_movies = Movie.query.order_by(Movie.title).all()
    return render_template('manage_movies.html', movies=all_movies, user=g.user)

# ----- ROUTE Halaman Menu ('/menu') -----
@app.route('/menu')
@login_required
def menu():
    return render_template('menu.html', user=g.user)

# --- ROUTE Halaman Pemesanan Kursi ('/seat_booking') ---
@app.route('/seat_booking', methods=['GET'])
@login_required
def seat_booking():
    all_movies = Movie.query.order_by(Movie.title).all()
    selected_movie = None
    movie_id = request.args.get('movie_id', type=int)

    if movie_id:
        selected_movie = Movie.query.get(movie_id)
        if not selected_movie:
            flash("Film tidak ditemukan.", "error")
            return redirect(url_for('seat_booking'))

    return render_template(
        'seat_booking.html',
        user=g.user,
        all_movies=all_movies,
        selected_movie=selected_movie,
        today=date.today() # Melewatkan tanggal hari ini untuk validasi min di input date
    )

# --- ROUTE untuk Memproses Pemesanan Kursi ('/process_booking') ---
@app.route('/process_booking/<int:movie_id>', methods=['POST'])
@login_required
def process_booking(movie_id):
    movie = Movie.query.get_or_404(movie_id)

    booking_date_str = request.form.get('booking_date')
    showtime = request.form.get('showtime')
    selected_seats = request.form.getlist('seats')

    if not booking_date_str or not showtime or not selected_seats:
        flash("Mohon lengkapi semua detail pemesanan: tanggal, waktu, dan pilih minimal satu kursi.", "error")
        return redirect(url_for('seat_booking', movie_id=movie_id))

    try:
        booking_date = datetime.strptime(booking_date_str, '%Y-%m-%d').date()

        # --- LOGIKA PENTING: HITUNG TOTAL HARGA DAN SIMPAN KE SESSION ---
        # Asumsi harga per kursi. GANTI INI DENGAN LOGIKA HARGA ASLI ANDA!
        PRICE_PER_SEAT = 35000 # Contoh harga per kursi (Rp 35.000)
        total_amount = len(selected_seats) * PRICE_PER_SEAT

        # Simpan detail booking ke dalam session
        session['current_booking_details'] = {
            'movie_title': movie.title,
            'booking_date': booking_date_str, # Tetap string untuk passing via URL atau session
            'showtime': showtime,
            'selected_seats': selected_seats, # Biarkan sebagai list
            'total_amount': total_amount
        }
        # --- AKHIR LOGIKA PENTING ---

        flash(f"Pemesanan untuk film '{movie.title}' pada {booking_date_str} jam {showtime} dengan kursi {', '.join(selected_seats)} berhasil diproses! Silakan lanjutkan ke pembayaran.", "success")

        # Redirect ke halaman payment. Data akan diambil dari session di rute /payment.
        # Tidak perlu lagi mengirim data via query params jika sudah ada di session
        return redirect(url_for('payment'))

    except ValueError:
        flash("Format tanggal pemesanan tidak valid.", "error")
        return redirect(url_for('seat_booking', movie_id=movie_id))
    except Exception as e:
        db.session.rollback()
        flash(f"Terjadi kesalahan saat memproses pemesanan: {str(e)}", "error")
        return redirect(url_for('seat_booking', movie_id=movie_id))

# --- BARU: ROUTE Halaman Pembayaran ('/payment') ---
@app.route('/payment', methods=['GET']) # Cukup GET karena data diambil dari session
@login_required
def payment():
    print("\n--- Memasuki fungsi payment ---") # Debugging
    
    # Ambil detail booking dari session
    booking_details = session.get('current_booking_details')
    print(f"Isi session['current_booking_details']: {booking_details}") # Debugging

    # Jika tidak ada detail booking di session, redirect ke halaman awal booking
    if not booking_details:
        flash('Tidak ada detail pemesanan yang ditemukan. Silakan pilih film dan kursi terlebih dahulu.', 'warning')
        print("ERROR: booking_details tidak ditemukan di session. Mengalihkan ke seat_booking.") # Debugging
        return redirect(url_for('seat_booking'))

    # Ekstrak data dari dictionary booking_details yang ada di session
    # Gunakan .get() dengan nilai default untuk mencegah UndefinedError jika kunci tidak ada
    movie_title = booking_details.get('movie_title', 'Judul Film Tidak Ditemukan')
    booking_date = booking_details.get('booking_date', 'Tanggal Tidak Ditemukan')
    showtime = booking_details.get('showtime', 'Waktu Tidak Ditemukan')
    selected_seats = booking_details.get('selected_seats', []) # Pastikan ini list, defaultnya list kosong
    total_amount = booking_details.get('total_amount', 0) # Pastikan ini angka, defaultnya 0

    print(f"Variabel yang akan dilewatkan ke template:") # Debugging
    print(f"  movie_title: {movie_title}")
    print(f"  booking_date: {booking_date}")
    print(f"  showtime: {showtime}")
    print(f"  selected_seats: {selected_seats}")
    print(f"  total_amount: {total_amount}")
    print(f"  user (current_user): {g.user.username if g.user else 'Tidak Login'}") # Debugging user

    # Baris 507 (sesuai traceback Anda) - Pastikan semua variabel dilewatkan
    return render_template(
        'payment.html',
        user=g.user,
        movie_title=movie_title,
        booking_date=booking_date,
        showtime=showtime,
        selected_seats=selected_seats, # Lewatkan sebagai list
        total_amount=total_amount # Lewatkan sebagai angka
    )


# ----- ROUTE Halaman Profil ('/profile') -----
@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html', user=g.user)

# ----- ROUTE Halaman Edit Profil ('/edit_profile') -----
@app.route('/edit_profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        current_user.Uname = request.form.get('Uname')
        current_user.email = request.form.get('email')

        dob_str = request.form.get('dob')
        if dob_str:
            try:
                current_user.dob = datetime.strptime(dob_str, '%Y-%m-%d').date()
            except ValueError:
                flash("Format tanggal lahir tidak valid.", "error")
                return redirect(url_for('edit_profile'))
        else:
            current_user.dob = None # Set ke None jika tidak ada tanggal yang dimasukkan

        # Penanganan Upload Foto Profil
        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file.filename == '':
                pass # Biarkan current_user.profile_picture tetap seperti semula
            elif allowed_file(file.filename):
                # Hapus gambar lama jika ada dan bukan default.jpg
                if current_user.profile_picture and current_user.profile_picture != 'default.jpg':
                    old_path = os.path.join(app.config['UPLOAD_FOLDER_PROFILE_PICTURES'], current_user.profile_picture)
                    if os.path.exists(old_path):
                        try:
                            os.remove(old_path)
                        except Exception as e:
                            print(f"WARNING: Gagal menghapus gambar lama: {e}")
                filename = secure_filename(file.filename)
                new_profile_picture_filename = f"{uuid.uuid4().hex}_{filename}"
                save_path = os.path.join(app.config['UPLOAD_FOLDER_PROFILE_PICTURES'], new_profile_picture_filename)

                try:
                    file.save(save_path)
                    current_user.profile_picture = new_profile_picture_filename
                except Exception as e:
                    flash(f"Terjadi kesalahan saat menyimpan gambar: {str(e)}", "error")
                    return redirect(url_for('edit_profile'))
            else:
                flash("Tipe file gambar tidak diizinkan. Hanya PNG, JPG, JPEG, GIF.", "warning")
                return redirect(url_for('edit_profile'))

    try:
        db.session.commit()
        flash('Profil berhasil diperbarui!', 'success')
        return redirect(url_for('profile'))
    except Exception as e:
        db.session.rollback()
        flash(f'Terjadi kesalahan saat memperbarui profil: {str(e)}', 'error')

    return render_template('edit_profile.html', user=g.user)


# ----- ROUTE Halaman Ganti Password ('/change_password') -----
@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        if not current_password or not new_password or not confirm_password:
            flash("Semua kolom password wajib diisi.", "error")
            return redirect(url_for('change_password'))

        if not current_user.check_password(current_password):
            flash("Password saat ini salah.", "error")
            return redirect(url_for('change_password'))

        if new_password != confirm_password:
            flash("Konfirmasi password baru tidak cocok.", "error")
            return redirect(url_for('change_password'))

        if len(new_password) < 6:
            flash("Password baru minimal 6 karakter.", "error")
            return redirect(url_for('change_password'))

        current_user.set_password(new_password)
        try:
            db.session.commit()
            flash('Password berhasil diubah!', 'success')
            return redirect(url_for('profile'))
        except Exception as e:
            db.session.rollback()
            flash(f'Terjadi kesalahan saat mengubah password: {str(e)}', 'error')

    return render_template('change_password.html', user=g.user)

# ----- ROUTE Halaman Hapus Akun ('/delete_account') -----
@app.route('/delete_account', methods=['GET', 'POST'])
@login_required
def delete_account():
    if request.method == 'POST':
        try:
            # Hapus file gambar profil jika ada dan bukan default.jpg
            if current_user.profile_picture and current_user.profile_picture != 'default.jpg':
                profile_pic_path = os.path.join(app.config['UPLOAD_FOLDER_PROFILE_PICTURES'], current_user.profile_picture)
                if os.path.exists(profile_pic_path):
                    os.remove(profile_pic_path)

            db.session.delete(current_user)
            db.session.commit()
            logout_user() # Logout setelah menghapus akun
            flash('Akun Anda telah berhasil dihapus.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Terjadi kesalahan saat menghapus akun: {str(e)}', 'error')

    return render_template('delete_account.html', user=g.user)


# ----- ROUTE Halaman Riwayat Pemesanan ('/booking_history') -----
@app.route('/booking_history')
@login_required
def booking_history():
    # Ini adalah data dummy. Di aplikasi nyata, Anda akan mengambil dari database.
    # Anda perlu membuat model untuk menyimpan riwayat pemesanan yang sebenarnya
    sample_bookings = [
        {'movie_title': 'Avengers: Endgame', 'date': '2025-07-01', 'time': '14:00', 'seats': 'A1, A2', 'description': 'Epic conclusion to the Infinity Saga.'},
        {'movie_title': 'Spiderman: No Way Home', 'date': '2025-06-25', 'time': '19:30', 'seats': 'D5', 'description': 'Peter Parker faces new challenges.'},
    ]
    return render_template('booking_history.html', bookings=sample_bookings, user=g.user)


# ----- ROUTE Halaman Pencarian ('/search') -----
@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('query', '')
    if query:
        search_results = Movie.query.filter(
            (Movie.title.ilike(f'%{query}%')) |
            (Movie.description.ilike(f'%{query}%')) |
            (Movie.director.ilike(f'%{query}%')) |
            (Movie.category.ilike(f'%{query}%'))
        ).all()
        if search_results:
            flash(f"Ditemukan {len(search_results)} hasil untuk '{query}'.", "info")
        else:
            flash(f"Tidak ada hasil ditemukan untuk '{query}'.", "warning")
    else:
        search_results = []
        flash("Silakan masukkan kata kunci pencarian.", "warning")

    return render_template('search_results.html', query=query, movies=search_results, user=g.user)

# ----- ROUTE Halaman Kontak ('/contact') -----
@app.route('/contact')
def contact():
    return render_template('contact.html', user=g.user)

if __name__ == '__main__':
    with app.app_context():
        db.create_all() # Membuat tabel jika belum ada
    app.run(debug=True)