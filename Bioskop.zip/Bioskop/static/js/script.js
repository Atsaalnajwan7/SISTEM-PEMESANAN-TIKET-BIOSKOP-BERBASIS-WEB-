document.addEventListener('DOMContentLoaded', function() {
    // Flash Messages Dismiss
    const flashMessages = document.getElementById('flash-messages');
    if (flashMessages) {
        setTimeout(() => {
            flashMessages.style.opacity = '0';
            setTimeout(() => flashMessages.remove(), 500); // Hapus setelah transisi
        }, 5000); // Hapus setelah 5 detik
    }

    // Dark/Light Mode Toggle
    const toggleBall = document.querySelector(".toggle-ball");
    toggleBall.addEventListener("click", () => {
        document.body.classList.toggle("light-mode");
    });

    // Redirect for Profile Selectbox
    window.redirectTo = function(select) {
        var url = select.value;
        if (url && url !== "settings") {
            window.location.href = url;
        }
    };

    // Hero Section Background Slideshow
    const heroSlides = document.querySelectorAll('.hero-slide');
    let currentSlide = 0;

    function showSlide(index) {
        heroSlides.forEach((slide, i) => {
            if (i === index) {
                slide.style.opacity = 1;
            } else {
                slide.style.opacity = 0;
            }
        });
    }

    function nextHeroSlide() {
        currentSlide = (currentSlide + 1) % heroSlides.length;
        showSlide(currentSlide);
    }

    // Initialize the first slide
    showSlide(currentSlide);

    // Change slide every 7 seconds (7000ms)
    setInterval(nextHeroSlide, 7000); 
});